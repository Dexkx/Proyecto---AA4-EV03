document.addEventListener('keyup', e =>{

    // enlace a la barra de búsqueda
    if (e.target.matches('#filtro')){

        // letras escritas en la barra de búsqueda se almacenan
        document.querySelectorAll('.article').forEach(articulo => {
            
            //compara la búsqueda hecha con los nombres de los articulos registrados y muestra la búsqueda deseada (a tiempo real)
            articulo.textContent.toLowerCase().includes(e.target.value)
            ? articulo.classList.remove('filtro')
            : articulo.classList.add('filtro');
        })
    }
})


