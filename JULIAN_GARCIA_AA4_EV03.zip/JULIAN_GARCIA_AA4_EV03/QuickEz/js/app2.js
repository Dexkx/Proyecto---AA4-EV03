import "../css/style.css";
import {useEffects, useState} from "react";
import axios from "axios";
import "boostrap/dist/css/boostrap.min.css";

function App(){

    //variables repositorias de la busqueda
    const [articulo, setArts]= useState([]);
    const [busqueda, setBusqueda]= useState("");

    // variable y método en el que los datos son autenticados
    const peticionGet=()=>{
        axios.get("")
        .then(response=>{
            setArts(response.data);
            setBusqueda(response.data);
        }).catch(error=>{
            console.log(error);
        })
    }
    
    useEffects(()=>{
        peticionGet();
    },[])

    // retorno al solicitar la función
    return(
        
    );

}

export default app2;
